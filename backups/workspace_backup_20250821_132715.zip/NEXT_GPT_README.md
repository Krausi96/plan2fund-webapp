# NEXT_GPT_README — Plan2Fund
**Workdir:** `C:\Users\kevin\plan2fund\one_prompt_webapp_agent_package\plan2fund-webapp`  
**Rules:** No new libs unless strictly required. Update `MIGRATION_REPORT.md` + `HANDOFF_BLOCK.json` after each change.

## Objectives (this shift)
1. Refine compliance scoring (map stage⇄TRL, sector filters, budget caps) — document weights.
2. Expand `programs.json` with concrete AWS/FFG variants (cap_eur, cofin_percent, typical_rejections, variant_notes).
3. Add DE/EN tooltips and copy polish for explanations.
4. Grow QA coverage to ≥ 6 seeds (positive + negative), assert **top-3 includes** expectations.
5. Keep `DEMO_SCRIPT.md` updated.

## Commands
```powershell
cd "C:\Users\kevin\plan2fund\one_prompt_webapp_agent_package\plan2fund-webapp"
npm install
.	ools\remove_bom.ps1
npm run dev
```

## Acceptance
- Dev server boots cleanly.
- Valid form → results + 3 export buttons.
- Print to PDF is clean.
- Console shows `Plan2Fund DEV Summary` with `ok=true`.
