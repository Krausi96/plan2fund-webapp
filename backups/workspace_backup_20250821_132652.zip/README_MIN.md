# Plan2Fund – Minimal README

Updated: 2025-08-17 20:41

## Run
```
npm install
npm run dev
```

## Exports
- Markdown: Results → Export Markdown
- JSON: Results → Export JSON
- PDF: Print/PDF button (uses browser print)

## QA
Selftests run in dev: see console.


**Troubleshooting:** see `docs/TROUBLESHOOTING.md` (BOM fix script in `tools/remove_bom.ps1`).


## PowerShell note (unsigned scripts)
If `tools\*.ps1` is blocked, run **only for this session**:
```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
.	oolsemove_bom.ps1
```
Alternatively, run the script directly bypassing policy:
```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .	oolsemove_bom.ps1
```
