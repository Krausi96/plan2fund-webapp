﻿MIGRATION REPORT - UI/Frontend Corporate Design Shift

Backup:
 - C:\Users\kevin\plan2fund\one_prompt_webapp_agent_package\plan2fund-webapp\backups\workspace_backup_20250821_132647.zip

Added/Updated:
 - src\config\flags.json
 - src\design\tokens.json
 - src\design\theme.css
 - src\design\motion.css
 - src\i18n\en.json
 - src\i18n\de.json
 - src\lib\i18n.js
 - src\components\Header.jsx
 - src\components\Footer.jsx
 - src\components\LangSwitch.jsx
 - src\components\Badge.jsx
 - src\components\Reveal.jsx
 - src\components\Orbs.jsx
 - src\components\Hero.jsx
 - src\components\ProductGrid.jsx
 - src\components\FeatureList.jsx
 - src\components\Steps.jsx
 - src\components\CTABand.jsx
 - src\dev\VisualCheck.jsx
 - src\shell\LandingShell.jsx
 - .\src\main.jsx

Sanitization:
 - merged root\components -> src\components (if existed)
 - quarantined duplicate copy files and conflicts to C:\Users\kevin\plan2fund\one_prompt_webapp_agent_package\plan2fund-webapp\.trash\20250821_132647
 - dist wiped; rebuilt clean

Notes:
 - No new deps. CSS-only motion; respects reduced motion.
 - Header hidden on landing via body[data-route='landing'].
 - /dev/visual-check renders components grid.
