## UI Shift — template entry
## UI Shift â€” 2025-08-21 16:46:15
- Design system added (design/*.css, tokens.json), i18n (lib/i18n.js, i18n/*.json)
- Landing hero + product blocks + CTA band, header hidden on landing
- Welcome route removed/redirected to /reco
- Flags: DESIGN_SYSTEM_ENABLED, ANIMATION_ENABLED, I18N_ENABLED = true; CONSENT_GRANTED = false
- Compliance doc added at docs/COMPLIANCE.md
- Files changed:
  - src\main.jsx
  - src\App.jsx
  - src\components\Landing.jsx
  - src\components\Welcome.jsx
