Rules diff (Step 7):
 = unchanged: aws_preseed
 = unchanged: ffg_basisprogramm
 = unchanged: eu_startup_call
 = unchanged: visa_rwr
 = unchanged: ams_wko_basic
 = unchanged: bank_loan_leasing