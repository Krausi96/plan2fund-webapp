
import React from "react";
export default function Orbs() {
  return (
    <div className="orbs" aria-hidden="true">
      <div className="orb" style={{left:"-6%", top:"-4%"}}/>
      <div className="orb"/>
      <div className="orb"/>
    </div>
  );
}
