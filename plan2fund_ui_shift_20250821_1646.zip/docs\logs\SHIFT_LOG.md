
### Shift 8 (2025-08-20 16:34:15)
User summary: Added the dynamic question bank and overlays in background; nothing changes on screen until we flip a flag. You can preview via a small placeholder panel.
Tech summary: Wrote /src/data/qbank.json, /src/data/overlays/*.overlay.json, and loader/render/entry JS. Added flags. Appended import to main.jsx as side-effect, gated by FORM_DYNAMIC_ENABLED.
Next: Step 9 (corpus seeds + education UI).
### Shift 9 (2025-08-20 16:44:52)
User summary: Added official-sources education UI (hidden by default) and stored the final user journey doc. System stays unchanged until we flip a flag.
Tech summary: Wrote corpus (big-6), education.ui.js + entry hook, updated flags, wrote USER_JOURNEY.md. No new deps. Safe.
Next: Step 10 (Exploration Mode intake).
### Shift 9 (2025-08-20 17:09:12)
User summary: Added official-sources education UI (hidden by default) and stored the final user journey doc. System stays unchanged until we flip a flag.
Tech summary: Wrote corpus (big-6), education.ui.js + entry hook, updated flags, wrote USER_JOURNEY.md. No new deps. Safe.
Next: Step 10 (Exploration Mode intake).