import React from "react";
export default function EligibilityBanner(){
  return (
    <div style={{fontSize:"12px",padding:"6px 8px",border:"1px dashed #ccc",borderRadius:"6px",margin:"8px 0"}}>
      Eligibility checks (stubbed)
    </div>
  );
}